import React from 'react'
import Testimonial from "../Components/Testimonial"
import Layout from '../Common/Layout'
import { Link } from 'react-router-dom'

const Feature = () => {
    return (
        <>
            <Layout>
                {/* <!-- Page Header Start --> */}
                <div className="container-fluid page-header mb-5">
                    <div className="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style={{ minHeight: '400px' }}>
                        <h4 className="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase font-weight-bold">Our Features</h4>
                        <div className="d-inline-flex">
                            <p className="m-0 text-white"><Link className="text-white" to="/">Home</Link></p>
                            <p className="m-0 text-white px-2">/</p>
                            <p className="m-0 text-white">Our Features</p>
                        </div>
                    </div>
                </div>
                {/* <!-- Page Header End --> */}

                {/* <!-- Features Start --> */}
                <div className="container-fluid my-5">
                    <div className="row">
                        <div className="col-lg-4 p-0">
                            <div className="d-flex align-items-center bg-secondary text-white px-5" style={{ minHeight: '300px' }}>
                                <i className="flaticon-training display-3 text-primary mr-3"></i>
                                <div className="">
                                    <h2 className="text-white mb-3">Progression</h2>
                                    <p>Consistent effort, gradual intensity increase, and dedication lead to satisfying and sustainable gym progression.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 p-0">
                            <div className="d-flex align-items-center bg-primary text-white px-5" style={{ minHeight: '300px' }}>
                                <i className="flaticon-weightlifting display-3 text-secondary mr-3"></i>
                                <div className="">
                                    <h2 className="text-white mb-3">Workout</h2>
                                    <p>Engage in a fulfilling workout for a healthier body, increased energy, and enhanced well-being.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 p-0">
                            <div className="d-flex align-items-center bg-secondary text-white px-5" style={{ minHeight: '300px' }}>
                                <i className="flaticon-treadmill display-3 text-primary mr-3"></i>
                                <div className="">
                                    <h2 className="text-white mb-3">Nutrition</h2>
                                    <p>Optimize performance and health with balanced nutrition, essential for fueling workouts and supporting overall well-being.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* <!-- Features End --> */}

                <Testimonial />
                
            </Layout>
        </>
    )
}

export default Feature